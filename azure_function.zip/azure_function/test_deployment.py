#!/usr/bin/env python3
"""
Test script for Azure Function deployment
"""

import requests
import json
import sys
import time

def test_local_function():
    """Test the locally running function"""
    print("🧪 Testing Local Azure Function")
    print("=" * 50)
    
    url = "http://localhost:7071/api/classify"
    
    test_cases = [
        {"description": "plastic water bottle"},
        {"description": "old battery"},
        {"description": "apple core"},
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\nTest {i}: {test_case['description']}")
        print("-" * 30)
        
        try:
            response = requests.post(url, json=test_case, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                print(f"✅ Classification: {result.get('bin', 'Unknown')}")
                print(f"   Item: {result.get('itemType', 'Unknown')}")
                print(f"   Confidence: {result.get('confidence', 0)}%")
            else:
                print(f"❌ Error {response.status_code}: {response.text}")
                
        except requests.exceptions.RequestException as e:
            print(f"❌ Connection error: {e}")
            print("   Make sure the function is running: func start --port 7071")
            return False
    
    return True

def test_deployed_function(function_url):
    """Test the deployed Azure function"""
    print(f"\n🌐 Testing Deployed Azure Function")
    print("=" * 50)
    print(f"URL: {function_url}")
    
    test_case = {"description": "plastic bottle"}
    
    try:
        print("\nSending test request...")
        response = requests.post(function_url, json=test_case, timeout=60)
        
        if response.status_code == 200:
            result = response.json()
            print("✅ Deployment successful!")
            print(f"   Classification: {result.get('bin', 'Unknown')}")
            print(f"   Item: {result.get('itemType', 'Unknown')}")
            print(f"   Confidence: {result.get('confidence', 0)}%")
            return True
        else:
            print(f"❌ Error {response.status_code}: {response.text}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Connection error: {e}")
        return False

def main():
    """Main test function"""
    print("Azure Function Deployment Tester")
    print("=" * 60)
    
    # Test local function first
    if len(sys.argv) == 1:
        print("Testing local development function...")
        success = test_local_function()
        
        if success:
            print("\n" + "=" * 60)
            print("✅ Local function tests passed!")
            print("\nTo test deployed function, run:")
            print("python test_deployment.py https://your-function-app.azurewebsites.net/api/classify")
        else:
            print("\n❌ Local function tests failed!")
            print("Make sure your function is running: func start --port 7071")
            sys.exit(1)
    
    # Test deployed function
    elif len(sys.argv) == 2:
        function_url = sys.argv[1]
        if not function_url.startswith('http'):
            print("❌ Please provide a valid URL starting with http:// or https://")
            sys.exit(1)
        
        success = test_deployed_function(function_url)
        
        if success:
            print("\n" + "=" * 60)
            print("✅ Deployed function is working!")
            print("\nYou can now update your mobile app:")
            print(f"EXPO_PUBLIC_AZURE_FUNCTION_URL={function_url}")
        else:
            print("\n❌ Deployed function test failed!")
            sys.exit(1)
    
    else:
        print("Usage:")
        print("  python test_deployment.py                          # Test local function")
        print("  python test_deployment.py <function-url>          # Test deployed function")
        sys.exit(1)

if __name__ == "__main__":
    main()