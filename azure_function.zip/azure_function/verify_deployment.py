#!/usr/bin/env python3
"""
Quick verification that o4-mini deployment is working
"""

import requests
import json
import time

# Your Azure Configuration
ENDPOINT = "https://admin-me7pqlig-swedencentral.cognitiveservices.azure.com"
API_KEY = "7SSugK7ix3pn75JGchqwuUSIJgDfUFmkYkIwt6WTd1rFyY2jI4UfJQQJ99BHACfhMk5XJ3w3AAAAACOGcKEU"
DEPLOYMENT = "o4-mini-deploy"

print("=" * 60)
print("🔍 Checking o4-mini Deployment Status")
print("=" * 60)

url = f"{ENDPOINT}/openai/deployments/{DEPLOYMENT}/chat/completions?api-version=2025-01-01-preview"
headers = {"api-key": API_KEY, "Content-Type": "application/json"}

# Test with waste classification
payload = {
    "messages": [
        {
            "role": "system",
            "content": "You are a waste classification expert. Classify the item and respond with: Category (Recycle/Compost/Landfill/Hazardous), Material, and Confidence (0-100%)."
        },
        {
            "role": "user",
            "content": "plastic water bottle"
        }
    ],
    "max_completion_tokens": 100
}

print(f"Testing deployment: {DEPLOYMENT}")
print("Sending test classification request...")

try:
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code == 200:
        print("\n✅ SUCCESS! o4-mini is deployed and working!")
        print("-" * 60)
        
        result = response.json()
        content = result['choices'][0]['message']['content']
        
        print("Test Classification Result:")
        print(content)
        print("-" * 60)
        print("\n🎉 Your Azure Function is ready to use!")
        print("The o4-mini model is successfully deployed.")
        
    elif response.status_code == 404:
        print("\n❌ Model not deployed yet")
        print("-" * 60)
        print("The o4-mini deployment is not ready.")
        print("\n⏳ WHAT TO DO:")
        print("1. Go to Azure AI Foundry")
        print("2. Check your Deployments")
        print("3. If deployment is in progress, wait 2-5 minutes")
        print("4. If not started, deploy 'o4-mini' model")
        print("5. Run this script again")
        
    else:
        print(f"\n❌ Error {response.status_code}")
        print(f"Response: {response.text[:500]}")
        
except Exception as e:
    print(f"\n❌ Connection error: {str(e)}")

print("=" * 60)