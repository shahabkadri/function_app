#!/usr/bin/env python3
"""
Troubleshoot Azure OpenAI connection
Tries different deployment names and API versions
"""

import requests
import json

# Your Azure AI Foundry Configuration
AZURE_OPENAI_API_KEY = "BJlGLkOh9EAjG7I3UjkA50Lrwh4qepDCUFKkDOmuBVjEzFVBgJB6JQQJ99BHACYeBjFXJ3w3AAAAACOGq9V7"

# Different configurations to try
configurations = [
    {
        "endpoint": "https://opn-ai-o4-mini.openai.azure.com",
        "deployment": "opn-ai-o4-mini",
        "api_version": "2024-10-21"
    },
    {
        "endpoint": "https://opn-ai-o4-mini.openai.azure.com",
        "deployment": "o4-mini",
        "api_version": "2024-10-21"
    },
    {
        "endpoint": "https://opn-ai-o4-mini.openai.azure.com",
        "deployment": "opn-ai-o4-mini",
        "api_version": "2024-08-01-preview"
    },
    {
        "endpoint": "https://opn-ai-o4-mini.openai.azure.com",
        "deployment": "o4-mini",
        "api_version": "2024-08-01-preview"
    },
    {
        "endpoint": "https://opn-ai-o4-mini.openai.azure.com",
        "deployment": "opn-ai-o4-mini",
        "api_version": "2025-04-01-preview"
    },
    {
        "endpoint": "https://opn-ai-o4-mini.openai.azure.com",
        "deployment": "o4-mini",
        "api_version": "2025-04-01-preview"
    }
]

def test_configuration(config):
    """Test a specific configuration"""
    endpoint = config["endpoint"]
    deployment = config["deployment"]
    api_version = config["api_version"]
    
    print(f"\nTesting: Deployment='{deployment}', API Version='{api_version}'")
    
    # Simple test message
    messages = [
        {
            "role": "user",
            "content": "Say 'Hello'"
        }
    ]
    
    # Construct the API URL
    url = f"{endpoint}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"
    
    # Headers with API key
    headers = {
        "api-key": AZURE_OPENAI_API_KEY,
        "Content-Type": "application/json"
    }
    
    # Try both parameter formats
    parameter_sets = [
        {"messages": messages, "max_completion_tokens": 50},  # o-series format
        {"messages": messages, "max_tokens": 50}  # GPT format
    ]
    
    for params in parameter_sets:
        try:
            response = requests.post(url, headers=headers, json=params)
            
            if response.status_code == 200:
                print(f"  ✅ SUCCESS with parameters: {list(params.keys())}")
                result = response.json()
                if 'choices' in result and len(result['choices']) > 0:
                    content = result['choices'][0]['message']['content']
                    print(f"  Response: {content}")
                return True
            elif response.status_code == 400 and "max_tokens" in params:
                # If max_tokens fails, try with max_completion_tokens
                continue
            else:
                if response.status_code != 400:  # Don't print 400 errors for parameter mismatches
                    print(f"  ❌ Failed ({response.status_code}): {response.json().get('error', {}).get('message', 'Unknown error')}")
                
        except Exception as e:
            print(f"  ❌ Error: {str(e)}")
    
    return False

def list_deployments():
    """Try to list available deployments"""
    print("\n" + "="*50)
    print("Attempting to list deployments...")
    
    # Try different endpoints for listing deployments
    endpoints = [
        "https://opn-ai-o4-mini.openai.azure.com/openai/deployments?api-version=2024-10-21",
        "https://opn-ai-o4-mini.openai.azure.com/openai/models?api-version=2024-10-21"
    ]
    
    headers = {
        "api-key": AZURE_OPENAI_API_KEY,
        "Content-Type": "application/json"
    }
    
    for endpoint in endpoints:
        try:
            response = requests.get(endpoint, headers=headers)
            if response.status_code == 200:
                print(f"✅ Found deployments at: {endpoint}")
                print(json.dumps(response.json(), indent=2))
                return
            else:
                print(f"❌ {endpoint}: {response.status_code}")
        except Exception as e:
            print(f"❌ Error: {str(e)}")

if __name__ == "__main__":
    print("="*50)
    print("Azure OpenAI Troubleshooting Tool")
    print("="*50)
    
    # Try to list deployments first
    list_deployments()
    
    print("\n" + "="*50)
    print("Testing different configurations...")
    print("="*50)
    
    success = False
    for config in configurations:
        if test_configuration(config):
            print(f"\n🎉 WORKING CONFIGURATION FOUND:")
            print(f"   Endpoint: {config['endpoint']}")
            print(f"   Deployment: {config['deployment']}")
            print(f"   API Version: {config['api_version']}")
            success = True
            break
    
    if not success:
        print("\n❌ No working configuration found.")
        print("\nPlease verify in Azure AI Foundry portal:")
        print("1. The exact deployment name (case-sensitive)")
        print("2. The deployment status is 'Succeeded'")
        print("3. The model is actually 'o4-mini'")
        print("4. The region matches your endpoint")