# Windows Deployment Guide for Azure Function App

## Prerequisites for Windows

### 1. Install Azure CLI for Windows
Download and install from: https://aka.ms/installazurecliwindows

Or use PowerShell (as Administrator):
```powershell
Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -OutFile .\AzureCLI.msi
Start-Process msiexec.exe -Wait -ArgumentList '/I AzureCLI.msi /quiet'
```

### 2. Install Azure Functions Core Tools
```powershell
npm install -g azure-functions-core-tools@4 --unsafe-perm true
```

## Deployment Steps

### Step 1: Login to Azure
```powershell
az login
```

### Step 2: Navigate to Function Directory
```powershell
cd azure_function
```

### Step 3: Deploy Your Python Code
```powershell
func azure functionapp publish eSmartBinFunctionApp --python
```

### Step 4: Set Environment Variables
```powershell
az functionapp config appsettings set `
  --name eSmartBinFunctionApp `
  --resource-group eSmartBin_RG `
  --settings AZURE_OPENAI_API_KEY="7SSugK7ix3pn75JGchqwuUSIJgDfUFmkYkIwt6WTd1rFyY2jI4UfJQQJ99BHACfhMk5XJ3w3AAAAACOGcKEU"
```

## Alternative: Deploy via ZIP File

If you prefer not to install Azure CLI, you can deploy via ZIP:

### Step 1: Create ZIP File
```powershell
# In the azure_function directory
Compress-Archive -Path * -DestinationPath function-app.zip
```

### Step 2: Upload via Azure Portal
1. Go to Azure Portal: https://portal.azure.com
2. Navigate to your Function App: `eSmartBinFunctionApp`
3. Go to "Deployment Center"
4. Choose "ZIP Deploy"
5. Upload your `function-app.zip` file

### Step 3: Set Environment Variables via Portal
1. In your Function App, go to "Configuration"
2. Click "New application setting"
3. Name: `AZURE_OPENAI_API_KEY`
4. Value: `7SSugK7ix3pn75JGchqwuUSIJgDfUFmkYkIwt6WTd1rFyY2jI4UfJQQJ99BHACfhMk5XJ3w3AAAAACOGcKEU`
5. Click "Save"

## Testing Your Deployment

### Test via PowerShell
```powershell
# Test classification
Invoke-RestMethod -Uri "https://eSmartBinFunctionApp.azurewebsites.net/api/classify" `
  -Method POST `
  -ContentType "application/json" `
  -Body '{"description": "plastic bottle"}'

# Test health check
Invoke-RestMethod -Uri "https://eSmartBinFunctionApp.azurewebsites.net/api/health"
```

## Final Step: Update Mobile App

Add this to your `.env` file:
```
EXPO_PUBLIC_AZURE_FUNCTION_URL=https://eSmartBinFunctionApp.azurewebsites.net/api/classify
```

Your function will be available at:
`https://eSmartBinFunctionApp.azurewebsites.net/api/classify`