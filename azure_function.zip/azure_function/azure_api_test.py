#!/usr/bin/env python3
"""
Direct Azure Cognitive Services API test
Tests the API endpoint directly without OpenAI SDK
"""

import requests
import json

# Configuration
ENDPOINT = "https://opn-ai-o4-mini.cognitiveservices.azure.com"
API_KEY = "BJlGLkOh9EAjG7I3UjkA50Lrwh4qepDCUFKkDOmuBVjEzFVBgJB6JQQJ99BHACYeBjFXJ3w3AAAAACOGq9V7"

print("=" * 60)
print("Azure Cognitive Services Direct API Test")
print("=" * 60)
print(f"Endpoint: {ENDPOINT}")
print("=" * 60)

# Test 1: Check if the endpoint is accessible
print("\n1. Testing endpoint accessibility...")
try:
    response = requests.get(
        f"{ENDPOINT}/openai/models?api-version=2024-10-01-preview",
        headers={"api-key": API_KEY}
    )
    
    if response.status_code == 200:
        print("✅ Endpoint is accessible")
        models = response.json()
        if 'data' in models and models['data']:
            print("\nAvailable models/deployments:")
            for model in models['data']:
                print(f"  - {model.get('id', 'Unknown')}")
        else:
            print("⚠️  No models found. You need to deploy a model first.")
    else:
        print(f"❌ Endpoint returned: {response.status_code}")
        print(f"Response: {response.text}")
except Exception as e:
    print(f"❌ Connection error: {str(e)}")

# Test 2: Try different API patterns
print("\n2. Testing different API patterns...")

test_patterns = [
    {
        "name": "OpenAI Pattern",
        "url": f"{ENDPOINT}/openai/deployments/gpt-4o-mini/chat/completions?api-version=2024-10-01-preview",
        "headers": {"api-key": API_KEY, "Content-Type": "application/json"},
        "data": {
            "messages": [{"role": "user", "content": "Hello"}],
            "max_tokens": 10
        }
    },
    {
        "name": "Cognitive Services Pattern",
        "url": f"{ENDPOINT}/language/:analyze-text?api-version=2023-04-01",
        "headers": {"Ocp-Apim-Subscription-Key": API_KEY, "Content-Type": "application/json"},
        "data": {
            "kind": "Conversation",
            "parameters": {"projectName": "gpt-4o-mini", "deploymentName": "gpt-4o-mini"},
            "analysisInput": {"conversationItem": {"text": "Hello"}}
        }
    }
]

for pattern in test_patterns:
    print(f"\nTrying {pattern['name']}...")
    try:
        response = requests.post(
            pattern['url'],
            headers=pattern['headers'],
            json=pattern['data']
        )
        
        if response.status_code == 200:
            print(f"  ✅ Success with {pattern['name']}")
            break
        elif response.status_code == 404:
            print(f"  ❌ Not found (404) - Model not deployed")
        else:
            print(f"  ❌ Error {response.status_code}")
    except Exception as e:
        print(f"  ❌ Error: {str(e)}")

print("\n" + "=" * 60)
print("NEXT STEPS:")
print("1. Deploy a model in Azure Portal or Azure AI Foundry")
print("2. Use the deployment name when making API calls")
print("3. Run this script again to verify")
print("=" * 60)