#!/usr/bin/env python3
"""
Direct test for Azure AI Foundry connection
This tests your Azure OpenAI credentials directly
"""

import requests
import json
import os

# Your Azure AI Foundry Configuration
AZURE_OPENAI_ENDPOINT = "https://admin-me7pqlig-swedencentral.cognitiveservices.azure.com"
AZURE_OPENAI_API_KEY = "7SSugK7ix3pn75JGchqwuUSIJgDfUFmkYkIwt6WTd1rFyY2jI4UfJQQJ99BHACfhMk5XJ3w3AAAAACOGcKEU"
DEPLOYMENT_NAME = "o4-mini-deploy"  # Model deployment name
API_VERSION = "2025-01-01-preview"  # API version for Azure AI Services

def test_azure_openai_connection():
    """Test direct connection to Azure OpenAI"""
    print("\n🔍 Testing Azure AI Foundry Connection...")
    print(f"Endpoint: {AZURE_OPENAI_ENDPOINT}")
    print(f"Deployment: {DEPLOYMENT_NAME}")
    print(f"API Version: {API_VERSION}")
    
    # Prepare a simple test message
    messages = [
        {
            "role": "system",
            "content": "You are a helpful assistant. Respond with a simple JSON object containing a 'status' field."
        },
        {
            "role": "user",
            "content": "Please respond with {\"status\": \"working\"}"
        }
    ]
    
    # Construct the API URL
    url = f"{AZURE_OPENAI_ENDPOINT}/openai/deployments/{DEPLOYMENT_NAME}/chat/completions?api-version={API_VERSION}"
    
    # Headers with API key
    headers = {
        "api-key": AZURE_OPENAI_API_KEY,
        "Content-Type": "application/json"
    }
    
    # Request payload
    payload = {
        "messages": messages,
        "max_completion_tokens": 100,  # gpt-4o-mini uses max_tokens
        "temperature": 0,
        "response_format": {"type": "json_object"}
    }
    
    print(f"\n📡 Calling: {url}")
    
    try:
        response = requests.post(url, headers=headers, json=payload)
        
        print(f"\n📊 Response Status: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            if 'choices' in result and len(result['choices']) > 0:
                content = result['choices'][0]['message']['content']
                print(f"✅ Success! Response: {content}")
                
                # Test waste classification
                test_waste_classification()
            else:
                print(f"❌ Unexpected response format: {result}")
        else:
            print(f"❌ Error: {response.status_code}")
            print(f"Response: {response.text}")
            
            if response.status_code == 401:
                print("\n⚠️  Authentication failed. Please check your API key.")
            elif response.status_code == 404:
                print("\n⚠️  Deployment not found. Please check your deployment name and endpoint.")
            elif response.status_code == 429:
                print("\n⚠️  Rate limit exceeded. Please wait and try again.")
                
    except Exception as e:
        print(f"❌ Connection error: {str(e)}")
        print("\n⚠️  Please check:")
        print("  1. Your internet connection")
        print("  2. The endpoint URL is correct")
        print("  3. Your API key is valid")

def test_waste_classification():
    """Test waste classification specifically"""
    print("\n🗑️  Testing Waste Classification...")
    
    # System prompt for waste classification
    system_prompt = """You are a waste classification AI. Classify the following item and respond with JSON:
{
  "itemType": "specific item name",
  "bin": "Recycle|Compost|Landfill|Hazardous",
  "confidence": 0-100
}"""
    
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": "Classify this item: plastic water bottle"}
    ]
    
    url = f"{AZURE_OPENAI_ENDPOINT}/openai/deployments/{DEPLOYMENT_NAME}/chat/completions?api-version={API_VERSION}"
    
    headers = {
        "api-key": AZURE_OPENAI_API_KEY,
        "Content-Type": "application/json"
    }
    
    payload = {
        "messages": messages,
        "max_tokens": 200,  # gpt-4o-mini uses max_tokens
        "temperature": 0.3,
        "response_format": {"type": "json_object"}
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload)
        
        if response.status_code == 200:
            result = response.json()
            if 'choices' in result and len(result['choices']) > 0:
                content = result['choices'][0]['message']['content']
                classification = json.loads(content)
                print(f"✅ Classification Success!")
                print(f"   Item: {classification.get('itemType')}")
                print(f"   Bin: {classification.get('bin')}")
                print(f"   Confidence: {classification.get('confidence')}%")
        else:
            print(f"❌ Classification failed: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Classification error: {str(e)}")

if __name__ == "__main__":
    print("=" * 50)
    print("Azure AI Foundry Connection Test")
    print("=" * 50)
    test_azure_openai_connection()