# Windows PowerShell deployment script for Azure Function App

Write-Host "🚀 Deploying to eSmartBinFunctionApp" -ForegroundColor Green
Write-Host "====================================" -ForegroundColor Green

# Check if Azure CLI is installed
if (!(Get-Command "az" -ErrorAction SilentlyContinue)) {
    Write-Host "❌ Azure CLI not found. Please install it first:" -ForegroundColor Red
    Write-Host "Download from: https://aka.ms/installazurecliwindows" -ForegroundColor Yellow
    exit 1
}

# Check if Azure Functions Core Tools is installed
if (!(Get-Command "func" -ErrorAction SilentlyContinue)) {
    Write-Host "❌ Azure Functions Core Tools not found. Installing..." -ForegroundColor Red
    npm install -g azure-functions-core-tools@4 --unsafe-perm true
}

# Check if user is logged in to Azure
Write-Host "🔐 Checking Azure login status..." -ForegroundColor Cyan
try {
    az account show | Out-Null
    Write-Host "✅ Azure login verified" -ForegroundColor Green
} catch {
    Write-Host "Please login to Azure first:" -ForegroundColor Yellow
    Write-Host "az login" -ForegroundColor White
    exit 1
}

# Deploy the function
Write-Host "📦 Deploying function code..." -ForegroundColor Cyan
func azure functionapp publish eSmartBinFunctionApp --python

# Set environment variables
Write-Host "🔑 Setting environment variables..." -ForegroundColor Cyan
az functionapp config appsettings set `
    --name eSmartBinFunctionApp `
    --resource-group eSmartBin_RG `
    --settings AZURE_OPENAI_API_KEY="7SSugK7ix3pn75JGchqwuUSIJgDfUFmkYkIwt6WTd1rFyY2jI4UfJQQJ99BHACfhMk5XJ3w3AAAAACOGcKEU"

Write-Host ""
Write-Host "🎉 Deployment Complete!" -ForegroundColor Green
Write-Host "======================" -ForegroundColor Green
Write-Host "Your function is available at:" -ForegroundColor White
Write-Host "https://eSmartBinFunctionApp.azurewebsites.net/api/classify" -ForegroundColor Yellow
Write-Host ""
Write-Host "📱 Update your mobile app .env file:" -ForegroundColor White
Write-Host "EXPO_PUBLIC_AZURE_FUNCTION_URL=https://eSmartBinFunctionApp.azurewebsites.net/api/classify" -ForegroundColor Yellow