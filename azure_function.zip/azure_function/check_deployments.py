#!/usr/bin/env python3
"""
Check which models are actually deployed and ready to use
"""

import requests
import json

# Your Azure AI Foundry Configuration
AZURE_OPENAI_ENDPOINT = "https://opn-ai-o4-mini.services.ai.azure.com"
AZURE_OPENAI_API_KEY = "BJlGLkOh9EAjG7I3UjkA50Lrwh4qepDCUFKkDOmuBVjEzFVBgJB6JQQJ99BHACYeBjFXJ3w3AAAAACOGq9V7"
API_VERSION = "2024-10-21"

# Test these common deployment names
test_deployments = [
    "o4-mini",
    "gpt-4o-mini",
    "gpt-4o",
    "gpt-4",
    "gpt-35-turbo",
    "gpt-3.5-turbo",
    "text-embedding-ada-002"
]

def test_deployment(deployment_name):
    """Test if a deployment exists and works"""
    url = f"{AZURE_OPENAI_ENDPOINT}/openai/deployments/{deployment_name}/chat/completions?api-version={API_VERSION}"
    
    headers = {
        "api-key": AZURE_OPENAI_API_KEY,
        "Content-Type": "application/json"
    }
    
    # Simple test message
    payload = {
        "messages": [{"role": "user", "content": "Say hello"}],
        "max_tokens": 10
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload)
        if response.status_code == 200:
            return True, "✅ Working"
        elif response.status_code == 404:
            return False, "Not deployed"
        else:
            return False, f"Error {response.status_code}"
    except Exception as e:
        return False, f"Error: {str(e)}"

print("=" * 50)
print("Checking Azure OpenAI Deployments")
print("=" * 50)
print(f"Endpoint: {AZURE_OPENAI_ENDPOINT}")
print("=" * 50)

working_deployments = []

for deployment in test_deployments:
    success, status = test_deployment(deployment)
    print(f"{deployment}: {status}")
    if success:
        working_deployments.append(deployment)

print("\n" + "=" * 50)
if working_deployments:
    print("✅ Working deployments found:")
    for dep in working_deployments:
        print(f"  - {dep}")
    print(f"\nRecommended: Use '{working_deployments[0]}' for your Azure Function")
else:
    print("❌ No working deployments found")
    print("\nNext steps:")
    print("1. Go to Azure AI Foundry portal")
    print("2. Click on 'Model catalog' in the left sidebar")
    print("3. Search for 'gpt-4o-mini' or 'gpt-35-turbo'")
    print("4. Click 'Deploy' and give it a name")
    print("5. Wait for deployment to complete")
    print("6. Run this script again")