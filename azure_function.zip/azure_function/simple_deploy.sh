#!/bin/bash
# Simple deployment script for your existing Azure Function App

echo "🚀 Deploying to eSmartBinFunctionApp"
echo "===================================="

# Check if user is logged in to Azure
echo "🔐 Checking Azure login status..."
if ! az account show &> /dev/null; then
    echo "Please login to Azure first:"
    echo "az login"
    exit 1
fi

echo "✅ Azure login verified"

# Deploy the function
echo "📦 Deploying function code..."
func azure functionapp publish eSmartBinFunctionApp --python

# Set environment variables
echo "🔑 Setting environment variables..."
az functionapp config appsettings set \
    --name eSmartBinFunctionApp \
    --resource-group eSmartBin_RG \
    --settings AZURE_OPENAI_API_KEY="7SSugK7ix3pn75JGchqwuUSIJgDfUFmkYkIwt6WTd1rFyY2jI4UfJQQJ99BHACfhMk5XJ3w3AAAAACOGcKEU"

echo ""
echo "🎉 Deployment Complete!"
echo "======================"
echo "Your function is available at:"
echo "https://eSmartBinFunctionApp.azurewebsites.net/api/classify"
echo ""
echo "📱 Update your mobile app .env file:"
echo "EXPO_PUBLIC_AZURE_FUNCTION_URL=https://eSmartBinFunctionApp.azurewebsites.net/api/classify"