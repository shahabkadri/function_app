#!/usr/bin/env python3
"""
Test script for Azure Function locally
Run this to test your Azure AI Foundry connection
"""

import requests
import json
import base64

# Local Azure Function URL (when running locally)
FUNCTION_URL = "http://localhost:7071/api/classify"

def test_text_classification():
    """Test text-only classification"""
    print("\n=== Testing Text Classification ===")
    
    payload = {
        "description": "plastic water bottle"
    }
    
    response = requests.post(FUNCTION_URL, json=payload)
    
    if response.status_code == 200:
        result = response.json()
        print(f"✅ Success!")
        print(f"Item: {result.get('itemType')}")
        print(f"Bin: {result.get('bin')}")
        print(f"Confidence: {result.get('confidence')}%")
        print(f"Tips: {result.get('tips')}")
    else:
        print(f"❌ Error: {response.status_code}")
        print(response.text)
    
    return response

def test_health_check():
    """Test health check endpoint"""
    print("\n=== Testing Health Check ===")
    
    response = requests.get("http://localhost:7071/api/health")
    
    if response.status_code == 200:
        result = response.json()
        print(f"✅ Health Check Success!")
        print(f"Status: {result.get('status')}")
        print(f"Endpoint: {result.get('endpoint')}")
        print(f"Deployment: {result.get('deployment')}")
    else:
        print(f"❌ Error: {response.status_code}")
        print(response.text)
    
    return response

if __name__ == "__main__":
    print("Smart Bin Azure Function Test")
    print("==============================")
    
    # Test health check first
    health_response = test_health_check()
    
    if health_response.status_code == 200:
        # Test text classification
        test_text_classification()
    else:
        print("\n❌ Health check failed. Please ensure the Azure Function is running.")
        print("Run: cd azure_function && func start")