#!/bin/bash
# Automated Azure Function Deployment Script

set -e  # Exit on any error

echo "🚀 Azure Function Deployment Script"
echo "===================================="

# Configuration (using your existing Azure resources)
RESOURCE_GROUP="eSmartBin_RG"
FUNCTION_APP="eSmartBinFunctionApp"
LOCATION="swedencentral"
API_KEY="7SSugK7ix3pn75JGchqwuUSIJgDfUFmkYkIwt6WTd1rFyY2jI4UfJQQJ99BHACfhMk5XJ3w3AAAAACOGcKEU"

echo "Configuration:"
echo "  Resource Group: $RESOURCE_GROUP"
echo "  Function App: $FUNCTION_APP"
echo "  Location: $LOCATION"
echo ""

# Check if Azure CLI is installed
if ! command -v az &> /dev/null; then
    echo "❌ Azure CLI not found. Please install it first:"
    echo "   curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash"
    exit 1
fi

# Check if user is logged in
if ! az account show &> /dev/null; then
    echo "🔐 Please login to Azure..."
    az login
fi

# Check if Azure Functions Core Tools is installed
if ! command -v func &> /dev/null; then
    echo "❌ Azure Functions Core Tools not found. Please install it first:"
    echo "   npm install -g azure-functions-core-tools@4 --unsafe-perm true"
    exit 1
fi

echo "✅ Prerequisites check passed"
echo ""

# Step 1: Verify existing resources
echo "🔍 Verifying existing Function App..."
if az functionapp show --name $FUNCTION_APP --resource-group $RESOURCE_GROUP &> /dev/null; then
    echo "   ✅ Function App '$FUNCTION_APP' found"
else
    echo "   ❌ Function App '$FUNCTION_APP' not found in resource group '$RESOURCE_GROUP'"
    exit 1
fi

# Step 2: Deploy Function Code
echo "📦 Deploying function code..."
func azure functionapp publish $FUNCTION_APP --python

# Step 3: Set Environment Variables
echo "🔑 Setting environment variables..."
az functionapp config appsettings set \
    --name $FUNCTION_APP \
    --resource-group $RESOURCE_GROUP \
    --settings AZURE_OPENAI_API_KEY="$API_KEY" \
    --output none
echo "   ✅ Environment variables configured"

# Step 4: Get Function URL
echo "🔗 Getting function URLs..."
FUNCTION_URL="https://$FUNCTION_APP.azurewebsites.net/api/classify"
HEALTH_URL="https://$FUNCTION_APP.azurewebsites.net/api/health"

echo ""
echo "🎉 Deployment Complete!"
echo "======================"
echo "Function App Name: $FUNCTION_APP"
echo "Classify URL: $FUNCTION_URL"
echo "Health URL: $HEALTH_URL"
echo ""
echo "📱 Update your mobile app .env file:"
echo "EXPO_PUBLIC_AZURE_FUNCTION_URL=$FUNCTION_URL"
echo ""

# Step 5: Test the deployment
echo "🧪 Testing deployment..."
sleep 30  # Wait for function to be ready

echo "Testing health endpoint..."
if curl -s "$HEALTH_URL" | grep -q "healthy"; then
    echo "   ✅ Health check passed"
else
    echo "   ⚠️  Health check failed (this might be normal for cold start)"
fi

echo ""
echo "Testing classification endpoint..."
if curl -s -X POST "$FUNCTION_URL" \
    -H "Content-Type: application/json" \
    -d '{"description": "plastic bottle"}' | grep -q "Recycle"; then
    echo "   ✅ Classification test passed"
else
    echo "   ⚠️  Classification test failed (check function logs)"
fi

echo ""
echo "✅ Deployment script completed!"
echo "You can monitor your function at: https://portal.azure.com"
echo "Resource Group: $RESOURCE_GROUP"