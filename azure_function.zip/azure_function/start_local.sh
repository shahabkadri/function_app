#!/bin/bash
# Start Azure Function locally for testing

echo "Starting Azure Function locally..."
echo "================================="

# Set environment variable
export AZURE_OPENAI_API_KEY="7SSugK7ix3pn75JGchqwuUSIJgDfUFmkYkIwt6WTd1rFyY2jI4UfJQQJ99BHACfhMk5XJ3w3AAAAACOGcKEU"

# Install Azure Functions Core Tools if not installed
if ! command -v func &> /dev/null
then
    echo "Installing Azure Functions Core Tools..."
    npm install -g azure-functions-core-tools@4 --unsafe-perm true
fi

# Navigate to azure_function directory
cd "$(dirname "$0")"

# Start the function
echo "Starting function on http://localhost:7071/api/classify"
echo "Press Ctrl+C to stop"
func start --port 7071