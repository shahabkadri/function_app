#!/usr/bin/env python3
"""
Test full waste classification with Azure Function
"""

import requests
import json
import base64

# Azure Configuration
ENDPOINT = "https://admin-me7pqlig-swedencentral.cognitiveservices.azure.com"
API_KEY = "7SSugK7ix3pn75JGchqwuUSIJgDfUFmkYkIwt6WTd1rFyY2jI4UfJQQJ99BHACfhMk5XJ3w3AAAAACOGcKEU"
DEPLOYMENT = "o4-mini-deploy"
API_VERSION = "2025-01-01-preview"

def test_classification(description):
    """Test waste classification with text description"""
    
    url = f"{ENDPOINT}/openai/deployments/{DEPLOYMENT}/chat/completions?api-version={API_VERSION}"
    headers = {"api-key": API_KEY, "Content-Type": "application/json"}
    
    # System prompt for waste classification
    system_prompt = """You are a waste classification AI trained on global standards (Basel, EU, EPA, WHO). 

Always output valid JSON:
{
  "itemType": "specific item name",
  "bin": "Hazardous|Compost|Recycle|Landfill|Special|N/A",
  "confidence": 0-100,
  "tips": "Disposal instructions with regulatory link",
  "certainty": "high|medium|low",
  "autoDescription": "Brief visual description",
  "categories": ["waste_type", "material_category"],
  "reasoning": ["reasoning step 1", "reasoning step 2"]
}"""

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"Classify this waste item: '{description}'. Output the JSON format."}
    ]
    
    payload = {
        "messages": messages,
        "max_completion_tokens": 500,
        "response_format": {"type": "json_object"}
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code == 200:
        result = response.json()
        content = result['choices'][0]['message']['content']
        return json.loads(content)
    else:
        return {"error": f"Status {response.status_code}: {response.text}"}

print("=" * 60)
print("🧪 Testing Azure o4-mini Waste Classification")
print("=" * 60)

# Test various waste items
test_items = [
    "plastic water bottle",
    "old battery",
    "apple core",
    "broken glass",
    "used motor oil"
]

for item in test_items:
    print(f"\n📦 Testing: {item}")
    print("-" * 40)
    
    result = test_classification(item)
    
    if "error" in result:
        print(f"❌ Error: {result['error']}")
    else:
        print(f"✅ Classification: {result.get('bin', 'Unknown')}")
        print(f"   Item Type: {result.get('itemType', 'Unknown')}")
        print(f"   Confidence: {result.get('confidence', 0)}%")
        print(f"   Tips: {result.get('tips', 'No tips available')[:100]}...")

print("\n" + "=" * 60)
print("✅ Azure Function is ready for production!")
print("=" * 60)