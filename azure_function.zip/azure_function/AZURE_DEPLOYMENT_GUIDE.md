# Azure AI Model Deployment Guide

## Your Current Setup
- **Endpoint**: https://opn-ai-o4-mini.cognitiveservices.azure.com
- **API Key**: Configured ✅
- **Models Deployed**: None ❌

## Step-by-Step: Deploy a Model in Azure AI Foundry

### Option 1: Deploy via Azure Portal

1. **Go to Azure Portal**
   - Visit [portal.azure.com](https://portal.azure.com)
   - Search for your resource: `opn-ai-o4-mini`
   - Click on your Cognitive Services resource

2. **Navigate to Model Deployments**
   - In the left menu, look for "Model deployments" or "Keys and Endpoint"
   - Click on "Go to Azure OpenAI Studio" or "Manage deployments"

3. **Create New Deployment**
   - Click "Create new deployment" or "Deploy model"
   - Select a model:
     - **gpt-4o-mini** (Recommended - Best balance)
     - **gpt-35-turbo** (Cheaper option)
     - **gpt-4o** (Most capable)
   
4. **Configure Deployment**
   - **Deployment name**: Enter exactly `gpt-4o-mini` (or the model name)
   - **Model**: Select the model version
   - **Deployment type**: Standard
   - Click "Create" or "Deploy"

5. **Wait for Deployment**
   - Status will change from "Creating" to "Succeeded"
   - This takes 2-5 minutes

### Option 2: Deploy via Azure AI Foundry Portal

1. **Go to Azure AI Foundry**
   - Visit [ai.azure.com](https://ai.azure.com)
   - Navigate to your project: eSmart Bin

2. **Deploy from Model Catalog**
   - Click "Model catalog" in left sidebar
   - Search for your desired model
   - Click on the model card
   - Click "Deploy"
   - Choose deployment configuration
   - Make sure to select your existing resource: `opn-ai-o4-mini`

### Option 3: Deploy via Azure CLI

```bash
# Install Azure CLI if not already installed
# Login to Azure
az login

# Create a deployment
az cognitiveservices account deployment create \
    --name opn-ai-o4-mini \
    --resource-group eSmartBin_RG \
    --deployment-name gpt-4o-mini \
    --model-name gpt-4o-mini \
    --model-version "2024-07-18" \
    --model-format OpenAI \
    --sku-capacity 10 \
    --sku-name "Standard"
```

## Common Deployment Names to Use

When deploying, use these exact names:
- `gpt-4o-mini` - For GPT-4o Mini model
- `gpt-35-turbo` - For GPT-3.5 Turbo model
- `gpt-4o` - For GPT-4o model

## Verify Deployment

After deployment, run this command to verify:
```bash
cd azure_function
python check_deployments.py
```

## Troubleshooting

### "Deployment Not Found" Error
- Model is not deployed yet
- Deployment name doesn't match
- Wait 5 minutes after deployment for it to be active

### "401 Unauthorized" Error
- API key is incorrect
- Check the key in Azure Portal

### "429 Too Many Requests" Error
- Rate limit exceeded
- Consider increasing quota or waiting

## Next Steps

1. Deploy a model using one of the methods above
2. Wait for deployment to complete (2-5 minutes)
3. Run `python check_deployments.py` to verify
4. Once verified, test with `python test_azure_connection.py`
5. Deploy the Azure Function for production use