import azure.functions as func
import json
import logging
import os
import base64
from typing import Dict, Any
import requests

# Azure Function App main file
app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)

# Azure AI Foundry Configuration
AZURE_OPENAI_ENDPOINT = "https://admin-me7pqlig-swedencentral.cognitiveservices.azure.com"
AZURE_OPENAI_API_KEY = os.environ.get("AZURE_OPENAI_API_KEY", "")
DEPLOYMENT_NAME = "o4-mini-deploy"  # Model deployment name
API_VERSION = "2025-01-01-preview"  # API version for Azure AI Services

@app.route(route="classify", methods=["POST"])
async def classify_waste(req: func.HttpRequest) -> func.HttpResponse:
    """
    Azure Function endpoint for waste classification
    Accepts image and/or text description and returns classification results
    """
    logging.info('Waste classification request received')

    try:
        # Parse request body
        req_body = req.get_json()
        
        # Extract parameters
        base64_image = req_body.get('image', '')
        user_description = req_body.get('description', '')
        
        if not base64_image and not user_description:
            return func.HttpResponse(
                json.dumps({"error": "Either image or description must be provided"}),
                status_code=400,
                mimetype="application/json"
            )
        
        # Prepare the messages for Azure OpenAI
        messages = []
        
        # System prompt for waste classification
        system_prompt = """You are a waste classification AI trained on global standards (Basel, EU, EPA, WHO). 
When both image and text are given, analyze the image first and classify based on visuals.

Always output valid JSON:
{
  "itemType": "specific item name",
  "bin": "Hazardous|Compost|Recycle|Landfill|Special|N/A",
  "confidence": 0-100,
  "tips": "Disposal instructions with regulatory link",
  "certainty": "high|medium|low",
  "autoDescription": "Brief visual description",
  "categories": ["waste_type", "material_category"],
  "reasoning": ["reasoning step 1", "reasoning step 2"]
}

Use null for unknown fields. If the image is unreadable, set all fields to null except "autoDescription":"Image could not be processed"."""

        messages.append({
            "role": "system",
            "content": system_prompt
        })
        
        # Prepare user message content
        user_content = []
        
        if user_description:
            text_content = f"Classify this waste item: '{user_description}'. Output the same JSON format as above."
        else:
            text_content = "Classify the waste shown in the image. Output the same JSON format as above."
        
        user_content.append({
            "type": "text",
            "text": text_content
        })
        
        if base64_image:
            user_content.append({
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/jpeg;base64,{base64_image}"
                }
            })
        
        messages.append({
            "role": "user",
            "content": user_content
        })
        
        # Call Azure OpenAI
        headers = {
            "api-key": AZURE_OPENAI_API_KEY,
            "Content-Type": "application/json"
        }
        
        # Construct the API URL
        url = f"{AZURE_OPENAI_ENDPOINT}/openai/deployments/{DEPLOYMENT_NAME}/chat/completions?api-version={API_VERSION}"
        
        # Prepare the request payload (o4-mini specific parameters)
        payload = {
            "messages": messages,
            "max_completion_tokens": 1000,
            "response_format": {"type": "json_object"}
        }
        
        logging.info(f"Calling Azure OpenAI at: {url}")
        
        # Make the API call
        response = requests.post(url, headers=headers, json=payload)
        
        if response.status_code != 200:
            logging.error(f"Azure OpenAI API error: {response.status_code} - {response.text}")
            return func.HttpResponse(
                json.dumps({
                    "error": f"AI service error: {response.status_code}",
                    "details": response.text
                }),
                status_code=500,
                mimetype="application/json"
            )
        
        # Parse the response
        result = response.json()
        
        # Extract the classification result
        if 'choices' in result and len(result['choices']) > 0:
            content = result['choices'][0]['message']['content']
            
            # Parse the JSON response
            try:
                classification = json.loads(content)
                
                # Add success flag
                classification['success'] = True
                
                logging.info(f"Classification successful: {classification.get('itemType', 'Unknown')}")
                
                return func.HttpResponse(
                    json.dumps(classification),
                    status_code=200,
                    mimetype="application/json"
                )
            except json.JSONDecodeError as e:
                logging.error(f"Failed to parse AI response: {e}")
                return func.HttpResponse(
                    json.dumps({
                        "error": "Failed to parse AI response",
                        "raw_response": content
                    }),
                    status_code=500,
                    mimetype="application/json"
                )
        else:
            return func.HttpResponse(
                json.dumps({
                    "error": "No response from AI service",
                    "details": result
                }),
                status_code=500,
                mimetype="application/json"
            )
            
    except Exception as e:
        logging.error(f"Error in classify_waste: {str(e)}")
        return func.HttpResponse(
            json.dumps({
                "error": "Internal server error",
                "message": str(e)
            }),
            status_code=500,
            mimetype="application/json"
        )

@app.route(route="health", methods=["GET"])
async def health_check(req: func.HttpRequest) -> func.HttpResponse:
    """Health check endpoint"""
    return func.HttpResponse(
        json.dumps({
            "status": "healthy",
            "service": "Smart Bin Waste Classification",
            "endpoint": AZURE_OPENAI_ENDPOINT,
            "deployment": DEPLOYMENT_NAME
        }),
        status_code=200,
        mimetype="application/json"
    )