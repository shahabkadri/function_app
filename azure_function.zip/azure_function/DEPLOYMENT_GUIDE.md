# Azure Function Deployment Guide

## Step 1: Prepare Your Azure Environment

### Install Azure CLI
```bash
# Install Azure CLI (if not already installed)
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash

# Login to Azure
az login
```

### Create Azure Resources
```bash
# Set variables (using your existing resources)
RESOURCE_GROUP="eSmartBin_RG"
FUNCTION_APP="eSmartBinFunctionApp"
LOCATION="swedencentral"

# Note: Using existing Function App, no need to create new resources
```

## Step 2: Deploy Your Python Code

### Deploy to Your Existing Function App
```bash
# Navigate to your function directory
cd azure_function

# Deploy to your existing Function App
func azure functionapp publish eSmartBinFunctionApp

# Set environment variables
az functionapp config appsettings set \
  --name eSmartBinFunctionApp \
  --resource-group eSmartBin_RG \
  --settings AZURE_OPENAI_API_KEY="7SSugK7ix3pn75JGchqwuUSIJgDfUFmkYkIwt6WTd1rFyY2jI4UfJQQJ99BHACfhMk5XJ3w3AAAAACOGcKEU"
```

### Alternative: Deploy from ZIP
```bash
# Create deployment package
zip -r function-app.zip . -x "*.git*" "__pycache__/*" "*.pyc"

# Upload via Azure CLI
az functionapp deployment source config-zip \
  --resource-group $RESOURCE_GROUP \
  --name $FUNCTION_APP \
  --src function-app.zip
```

## Step 3: Test Your Deployed Function

### Get Function URL
```bash
# Get the function URL (using your Function App name)
FUNCTION_URL="https://eSmartBinFunctionApp.azurewebsites.net/api/classify"
HEALTH_URL="https://eSmartBinFunctionApp.azurewebsites.net/api/health"

echo "Function URL: $FUNCTION_URL"
echo "Health URL: $HEALTH_URL"
```

### Test the Function
```bash
# Test classification endpoint
curl -X POST "$FUNCTION_URL" \
  -H "Content-Type: application/json" \
  -d '{"description": "plastic water bottle"}' | python -m json.tool

# Test health endpoint
HEALTH_URL="${FUNCTION_URL/classify_waste/health_check}"
curl "$HEALTH_URL"
```

## Step 4: Configure Mobile App

### Update Environment Variables
Add to your `.env` file:
```
EXPO_PUBLIC_AZURE_FUNCTION_URL=https://eSmartBinFunctionApp.azurewebsites.net/api/classify
```

## Step 5: Verify Everything Works

### Test End-to-End
1. Deploy function to Azure ✓
2. Update mobile app configuration ✓
3. Test classification from mobile app ✓
4. Monitor logs in Azure Portal ✓

### Monitor Function
```bash
# View logs
func azure functionapp logstream $FUNCTION_APP

# Check function status
az functionapp show --name $FUNCTION_APP --resource-group $RESOURCE_GROUP --query "state"
```

## Troubleshooting

### Common Issues
1. **Deployment fails**: Check Python version (must be 3.11)
2. **Function timeout**: Increase timeout in function.json
3. **API key error**: Verify environment variable is set
4. **CORS issues**: Configure CORS in Azure Portal

### Debug Commands
```bash
# Check function app settings
az functionapp config appsettings list --name eSmartBinFunctionApp --resource-group eSmartBin_RG

# View function app logs
az webapp log tail --name eSmartBinFunctionApp --resource-group eSmartBin_RG

# Test locally first
cd azure_function && func start --port 7071
```

## Security Checklist
- [ ] API keys stored as environment variables (not in code)
- [ ] CORS configured for your mobile app domain
- [ ] Function authentication enabled if needed
- [ ] Monitor usage and costs in Azure Portal

## Cost Optimization
- Use Consumption plan for development
- Monitor function execution metrics
- Set up alerts for unusual usage
- Consider dedicated plans for high traffic

Your function will be available at:
`https://eSmartBinFunctionApp.azurewebsites.net/api/classify`