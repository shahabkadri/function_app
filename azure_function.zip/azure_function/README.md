# Azure Function for Smart Bin

## Overview
This Azure Function provides a secure proxy layer between the Smart Bin mobile app and Azure OpenAI services, ensuring API keys are never exposed in the client application.

## Current Configuration
- **Azure Endpoint**: https://admin-me7pqlig-swedencentral.cognitiveservices.azure.com
- **Model Deployment**: o4-mini-deploy
- **Region**: Sweden Central
- **Status**: ✅ Operational

## Local Development

### Prerequisites
- Python 3.11+
- Azure Functions Core Tools v4
- Azure OpenAI API key

### Running Locally
```bash
# Navigate to azure_function directory
cd azure_function

# Set environment variable
export AZURE_OPENAI_API_KEY="your-api-key"

# Start the function
func start --port 7071
```

The function will be available at: `http://localhost:7071/api/classify`

## API Endpoints

### POST /api/classify
Classify waste items using AI.

**Request Body:**
```json
{
  "image": "base64_encoded_image_string",  // Optional
  "description": "item description"         // Optional (at least one required)
}
```

**Response:**
```json
{
  "success": true,
  "itemType": "plastic water bottle",
  "bin": "Recycle",
  "confidence": 95,
  "tips": "Rinse and place in recycling bin",
  "certainty": "high",
  "categories": ["plastic", "recyclable"],
  "reasoning": ["Made from PET plastic", "Widely recyclable"]
}
```

### GET /api/health
Health check endpoint.

## Deployment to Azure

### Deploy to Existing Function App
```bash
# Deploy to your existing Function App
func azure functionapp publish eSmartBinFunctionApp

# Set environment variables
az functionapp config appsettings set --name eSmartBinFunctionApp --resource-group eSmartBin_RG --settings AZURE_OPENAI_API_KEY="your-api-key"
```

## Security Features
- API keys stored as environment variables
- CORS configured for mobile app access
- Function-level authentication
- No sensitive data logged

## Testing
```bash
# Test classification
curl -X POST http://localhost:7071/api/classify \
  -H "Content-Type: application/json" \
  -d '{"description": "plastic bottle"}'

# Health check
curl http://localhost:7071/api/health
```

## Mobile App Integration
Update the mobile app's `.env` file:
```
EXPO_PUBLIC_AZURE_FUNCTION_URL=https://eSmartBinFunctionApp.azurewebsites.net/api/classify
```

The mobile app will automatically use the Azure Function for all AI classifications.