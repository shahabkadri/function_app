#!/usr/bin/env python3
"""
Test Azure AI Services endpoint directly
"""

import requests
import json

# Configuration
ENDPOINT = "https://opn-ai-o4-mini.services.ai.azure.com"
API_KEY = "BJlGLkOh9EAjG7I3UjkA50Lrwh4qepDCUFKkDOmuBVjEzFVBgJB6JQQJ99BHACYeBjFXJ3w3AAAAACOGq9V7"

print("=" * 60)
print("Testing Azure AI Services Endpoint")
print("=" * 60)
print(f"Endpoint: {ENDPOINT}")
print("=" * 60)

# Test 1: Check available models
print("\n1. Checking available models...")
url = f"{ENDPOINT}/openai/models?api-version=2024-10-21"
headers = {"api-key": API_KEY}

try:
    response = requests.get(url, headers=headers)
    print(f"Response status: {response.status_code}")
    
    if response.status_code == 200:
        models = response.json()
        if 'data' in models:
            print(f"\n✅ Found {len(models['data'])} available models")
            # Look for o4-mini specifically
            o4_models = [m for m in models['data'] if 'o4' in m.get('id', '').lower()]
            if o4_models:
                print("\n🎯 O4 models available:")
                for model in o4_models:
                    print(f"  - {model.get('id')}")
        else:
            print("No models data found")
    else:
        print(f"Error response: {response.text[:500]}")
except Exception as e:
    print(f"Connection error: {str(e)}")

# Test 2: Try to call o4-mini deployment
print("\n2. Testing o4-mini deployment...")
deployments_to_test = ["o4-mini", "gpt-4o-mini", "gpt-35-turbo"]

for deployment in deployments_to_test:
    print(f"\nTrying deployment: {deployment}")
    url = f"{ENDPOINT}/openai/deployments/{deployment}/chat/completions?api-version=2024-10-21"
    
    payload = {
        "messages": [{"role": "user", "content": "Hello"}],
        "max_tokens": 10
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload)
        
        if response.status_code == 200:
            print(f"  ✅ SUCCESS! Deployment '{deployment}' is working!")
            result = response.json()
            print(f"  Response: {result['choices'][0]['message']['content']}")
            break
        elif response.status_code == 404:
            print(f"  ❌ Not found - '{deployment}' not deployed")
        else:
            print(f"  ❌ Error {response.status_code}: {response.text[:200]}")
    except Exception as e:
        print(f"  ❌ Error: {str(e)}")

print("\n" + "=" * 60)
print("DEPLOYMENT STATUS:")
print("=" * 60)
print("\n📋 TO DEPLOY A MODEL:")
print("1. Go to Azure AI Foundry: https://ai.azure.com")
print("2. Navigate to your project: eSmart Bin")
print("3. Click 'Deployments' in the left menu")
print("4. Click '+ Deploy model' button")
print("5. Select 'o4-mini' or 'gpt-4o-mini'")
print("6. Name it exactly: 'o4-mini' (or 'gpt-4o-mini')")
print("7. Click 'Deploy' and wait 2-5 minutes")
print("\n💡 Once deployed, this script should show SUCCESS!")
print("=" * 60)